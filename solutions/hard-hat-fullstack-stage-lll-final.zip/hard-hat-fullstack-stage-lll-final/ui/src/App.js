

import Transactions from './components/transactions';
import Wallet from './components/wallet'
import Accounts from './components/accounts'
import Navigation from './components/navigation';
import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";
import Transfer from './components/transfer';

function App() {
  return (
    <BrowserRouter>
    <Navigation />
    <Routes>
        <Route path="/" element={<Transactions />} />
        <Route path="/addresses" element={<Accounts />} />
        <Route path="/addresses/wallet/:address" element={<Transfer />} />
        <Route path="/wallet" element={<Wallet />} />
    </Routes>
  </BrowserRouter>
  );
}

export default App;
