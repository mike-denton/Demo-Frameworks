import { DEFAULT_WALLET_ADDRESS} from '../constants'

import React, { useEffect, useState } from "react"
import { useParams } from "react-router-dom";
import axios from 'axios'
import Receipt from "./receipt";

function Transfer (props) {

    let params = useParams();
   const [input, setInput] = useState("")
   const [receipt, setReceipt] = useState({})

    useEffect(() => {
     
    },[])
 
    const handleInputChange = (e) =>{ 
       console.log(`handle input change ${e.target.value}`)
      setInput(
       e.target.value
    )
   }
    const handleSubmit = (e) => {
        e.preventDefault();
        alert(`current value of input: ${input}`)
        axios.post("http://localhost:3001/transaction/send",
        {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
           data: {
           source: DEFAULT_WALLET_ADDRESS,
           destination: params.address,
           amount: input
        }
      })
        .then(data => {
           setReceipt(data)
            console.log(data)
        })
    }
    const buildTransferDetails = () => {
          //console.log(`buildWalletDetails: ${JSON.stringify(wallet)}`)
          return (
             <>
               <form onSubmit={ handleSubmit } className="container">
                  <p><b>From:</b> {DEFAULT_WALLET_ADDRESS}</p>
                  <p><b>To:</b> {params.address} </p>
                  <p><b>Amount:</b> <input type="textbox" width={50} value={input} onChange={handleInputChange}/> </p>
                  <p><button type="submit">Submit</button></p>
                </form>
                <Receipt {...receipt.data} />
             </>
          )
       
    }
     return(
        <>
           <h1>Transfer</h1>
           { buildTransferDetails() }
        </>
     )
 
 }
 
 export default Transfer;