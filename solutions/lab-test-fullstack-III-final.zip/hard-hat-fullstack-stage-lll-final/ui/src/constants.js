const DEFAULT_SOURCE_ADDRESS = "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266"
const DEFAULT_DESTINATION_ADDRESS = "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266"

// eslint-disable-next-line import/no-anonymous-default-export
module.exports = {
    DEFAULT_SOURCE_ADDRESS,
    DEFAULT_DESTINATION_ADDRESS
}