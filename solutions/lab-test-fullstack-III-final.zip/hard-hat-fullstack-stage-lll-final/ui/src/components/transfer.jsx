import { DEFAULT_SOURCE_ADDRESS, DEFAULT_DESTINATION_ADDRESS } from '../constants'

import React, { useState } from "react"
import axios from 'axios'

function Transfer (props) {

   const [input, setInput] = useState("")
 
    const handleInputChange = (e) =>{ 
       console.log(`handle input change ${e.target.value}`)
      setInput(
       e.target.value
    )
   }
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(`transfer submit handler..`)
        axios.post("http://localhost:3001/transaction/send",
        {
           headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
           data: {
           source: DEFAULT_SOURCE_ADDRESS,
           destination: DEFAULT_DESTINATION_ADDRESS,
           amount: input
        }
      })
        .then(data => {
            console.log(data)
        })
    }
  
     return(
        <React.Fragment>
           <h1>Transfer</h1>
               <form onSubmit={ handleSubmit } className="container">
                  <p><b>From:</b> {DEFAULT_SOURCE_ADDRESS}</p>
                  <p><b>To:</b> {DEFAULT_DESTINATION_ADDRESS} </p>
                  <p><b>Amount:</b> <input type="textbox" width={50} value={input} onChange={handleInputChange}/> </p>
                  <p><button type="submit">Submit</button></p>
                </form>
        </React.Fragment>
     )
 
 }
 
 export default Transfer;